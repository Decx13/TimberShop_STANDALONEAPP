package lk.ijse.timbershop.service.custom.impl;

import lk.ijse.timbershop.dao.custom.CustomerDAO;
import lk.ijse.timbershop.dao.custom.CustomerOrderDAO;
import lk.ijse.timbershop.dao.custom.ItemDAO;
import lk.ijse.timbershop.dao.custom.impl.CustomerDAOImpl;
import lk.ijse.timbershop.dao.custom.impl.CustomerOrderDAOImpl;
import lk.ijse.timbershop.dao.custom.impl.ItemDAOImpl;
import lk.ijse.timbershop.service.custom.CustomerOrderService;
import lk.ijse.timbershop.to.Item;

import java.sql.SQLException;
import java.util.ArrayList;

public class CustomerOrderServiceImpl implements CustomerOrderService {
    ItemDAO itemDAO= new ItemDAOImpl();
    CustomerDAO customerDAO=new CustomerDAOImpl();
    CustomerOrderDAO customerOrderDAO=new CustomerOrderDAOImpl();


    @Override
    public ArrayList<String> loadItemCodes() throws SQLException, ClassNotFoundException {
        return itemDAO.loadItemCodes();
    }

    @Override
    public Item search(String ItemCode) throws SQLException, ClassNotFoundException {
        return itemDAO.search(ItemCode);
    }

    @Override
    public ArrayList<String> loadCustomerIds() throws SQLException, ClassNotFoundException {
        return customerDAO.loadCustomerIds();
    }

    @Override
    public String generateNextOrderId() throws SQLException, ClassNotFoundException {
        return customerOrderDAO.generateNextOrderId();
    }
}
