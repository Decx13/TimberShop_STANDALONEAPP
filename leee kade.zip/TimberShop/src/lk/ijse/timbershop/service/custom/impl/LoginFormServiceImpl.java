package lk.ijse.timbershop.service.custom.impl;

import lk.ijse.timbershop.dao.custom.UserDAO;
import lk.ijse.timbershop.dao.custom.impl.UserDAOImpl;
import lk.ijse.timbershop.service.custom.LoginFormService;
import lk.ijse.timbershop.to.User;

import java.sql.SQLException;

public class LoginFormServiceImpl implements LoginFormService {
    UserDAO userDAO=new UserDAOImpl();

    @Override
    public boolean signUp(User user) throws SQLException, ClassNotFoundException {
        return userDAO.add(user);
    }
}
