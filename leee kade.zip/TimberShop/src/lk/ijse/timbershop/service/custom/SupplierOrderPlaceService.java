package lk.ijse.timbershop.service.custom;

import lk.ijse.timbershop.to.SupplierOrderPlace;

import java.sql.SQLException;

public interface SupplierOrderPlaceService {
    boolean SupplierPlaceOrder(SupplierOrderPlace supplierOrderPlace) throws SQLException, ClassNotFoundException;
}
