package lk.ijse.timbershop.service.custom;

import lk.ijse.timbershop.to.User;

import java.sql.SQLException;

public interface LoginFormService {
    boolean signUp(User user) throws SQLException, ClassNotFoundException;
}
