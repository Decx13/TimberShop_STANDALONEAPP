package lk.ijse.timbershop.service;

public interface SuperService {
}
