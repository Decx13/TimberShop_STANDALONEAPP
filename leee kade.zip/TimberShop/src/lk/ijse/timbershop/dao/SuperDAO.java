package lk.ijse.timbershop.dao;

public interface SuperDAO {
}
