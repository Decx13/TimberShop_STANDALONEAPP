package lk.ijse.timbershop.dao.custom;

import lk.ijse.timbershop.dao.CrudDAO;
import lk.ijse.timbershop.to.User;

public interface UserDAO extends CrudDAO<User,String> {
}
