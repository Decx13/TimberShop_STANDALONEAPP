package lk.ijse.timbershop.util;

public enum Routes {
    furniture,selling;

}