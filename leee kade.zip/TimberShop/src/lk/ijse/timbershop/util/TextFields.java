package lk.ijse.timbershop.util;

public enum TextFields {
    ID,LANKAN_ID,NAME,EMAIL,PHONE,INTEGER,DOUBLE,ADDRESS,NONE_CHARACTER,INVOICE
}
